#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Proprietary Python Script
=========================

This Python script demonstrates a comprehensive data generation utility. 
It parses SQL CREATE TABLE statements to dynamically create columns and generate mock data for each column based on predefined configurations. 
The script supports both regular and gzipped CSV output, with data types like integers, strings, floats, and datetimes. 
It allows custom randomization logic for generating data, such as random string lengths and ranges for integers. 
Configurations are managed through an external JSON file, and the script can be customized using command-line arguments to specify the path to the configuration file.

Usage:
    prepare configuration file
    python3 netgen.py --config "<config_file_path>"

This software is confidential and proprietary to Netcore Cloud. 
Unauthorized copying, modification, or distribution is strictly prohibited.

Author:
    Vishal Police Patil (vishal.p@netcorecloud.com)
    
Copyright (c) 2024 Netcore Cloud. All Rights Reserved.
"""

import json
import re
import random
from datetime import datetime, timedelta
import string
import csv
import gzip
import argparse
import concurrent.futures
import time


config_data = None
BATCH_SIZE = 1000


def read_config(file_path):
    global config_data
    with open(file_path, 'r') as file:
        config_data = json.load(file)


def get_cid(input_dict):
    cumulative_percent = []
    total_percent = 0
    
    for value, percent in input_dict.items():
        total_percent += percent
        cumulative_percent.append((value, total_percent))
    
    rand_num = random.randint(1, 100)
    
    for value, percent in cumulative_percent:
        if rand_num <= percent:
            if value == "-1":
                return random.randint(10000, 99999)
            return value


def get_uid(start_value=None):
    if start_value is None:
        start_value = config_data['uid_start_value']
    current_value = start_value
    while True:
        yield current_value
        current_value += 1


def restrict_uids(uid, cid, enum, total_cids, cid_count):
    original_cid = cid
    
    if cid not in enum:
        cid = "-1"
    
    allowed_count = (enum[cid] * total_cids) / 100
    
    if cid_count.get(cid, 0) < allowed_count:
        cid_count[cid] = cid_count.get(cid, 0) + 1
        return original_cid
    else:
        return None 


def generate_incremental_datetimes(startdatetime_str, enddatetime_str, number_of_dates):
    """
    Generate incremental datetime values between startdatetime and enddatetime.
    
    Args:
        startdatetime_str: Start datetime in '240909130631' format (YYMMDDHHMMSS).
        enddatetime_str: End datetime in '240909130631' format (YYMMDDHHMMSS), or empty for today's date.
        number_of_dates: Number of datetime values to generate.
    
    Yields:
        Incremental datetime values in 'YYMMDDHHMMSS' format.
    """
    
    start_datetime = datetime.strptime(startdatetime_str, "%y%m%d%H%M%S")
    
    if enddatetime_str:
        end_datetime = datetime.strptime(enddatetime_str, "%y%m%d%H%M%S")
    else:
        end_datetime = datetime.now()
    
    total_time_diff = end_datetime - start_datetime
    
    # If the date range is smaller than the number of dates, duplicate some values
    if total_time_diff.total_seconds() == 0:
        # If start and end time are the same, yield the same datetime multiple times
        interval = timedelta(0)
    else:
        interval = total_time_diff / (number_of_dates - 1)
    
    current_datetime = start_datetime
    
    for _ in range(number_of_dates):
        yield current_datetime.strftime("%y%m%d%H%M%S")
        current_datetime += interval
        # If we exceed the end time, yield the end time repeatedly
        if current_datetime > end_datetime:
            current_datetime = end_datetime


def get_date_time_numeric(startdatetime_str, enddatetime_str, interval):
    date_time_generator = generate_incremental_datetimes(startdatetime_str, enddatetime_str, interval)
    return date_time_generator    


def get_ctime(datetime_str):
    dt = datetime.strptime(datetime_str, '%y%m%d%H%M%S')
    formatted_dt = dt.strftime('%Y-%m-%d %H:%M:%S')
    return formatted_dt


def parse_length(length_str):
    '''Check if string contains ranges or a single value'''
    if '-' in length_str:
        l, r = map(int, length_str.split('-'))
        return True, l, r
    elif len(length_str) == 0:
        return False, None, None
    else:
        return False, int(length_str), None


def get_random_string(length_range):
    is_range, l, r = parse_length(length_range)
    
    if is_range:
        length = random.randint(l, r)
    else:
        if l is not None:
            length = l
        else:
            is_range, l, r = parse_length(config_data['default_random_string_length_range'])
            length = random.randint(1, 20)
    
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def get_random_int(length_range):
    is_range, l, r = parse_length(length_range)
    if is_range:
        return random.randint(l, r-1)
    else:
        is_range, l, r = parse_length(config_data['default_random_int_range'])
        return random.randint(l, r)


def get_random_datetime():
    return datetime.now().strftime('%y%m%d%H%M%S')


def get_random_float():
    return random.uniform(0.0, 100.0)


class Column:
    def __init__(self, name, data_type, is_not_null, percent_of_not_null_columns=None, enum=None, length_range=None):
        self.name = name
        self.data_type = data_type
        self.is_not_null = is_not_null
        if percent_of_not_null_columns is None:
            self.percent_of_not_null_columns = config_data['default_percent_of_not_null_columns']
        if enum is None:
            self.enum = config_data['default_enum']
        if length_range is None:
            self.length_range = config_data['default_length_range']
    
    def __repr__(self):
        return f"Column(name={self.name}, data_type={self.data_type}, is_not_null={self.is_not_null})"


def map_sql_to_python_type(sql_type):
    sql_type = sql_type.lower()
    if 'int' in sql_type:
        return 'int'
    elif 'float' in sql_type or 'double' in sql_type:
        return 'float'
    elif 'varchar' in sql_type or 'char' in sql_type or 'string' in sql_type:
        return 'str'
    elif 'timestamp' in sql_type or 'datetime' in sql_type or 'date' in sql_type:
        return 'datetime'
    else:
        return 'str'

class Columns:
    def __init__(self):
        self.columns = []
    
    def add_column(self, column):
        self.columns.append(column)

    def get_columns(self):
        return self.columns
    
    def update_from_dict(self, fixed_columns):
        column_dict = {col.name: col for col in self.columns}
        
        for col_name, attributes in fixed_columns.items():
            if col_name in column_dict:
                col = column_dict[col_name]
                data_type, is_not_null, percent_of_not_null_columns, enum, length_range = attributes
                
                col.data_type = map_sql_to_python_type(data_type)  # Ensure data_type is mapped to Python type
                col.is_not_null = is_not_null
                col.percent_of_not_null_columns = percent_of_not_null_columns
                col.enum = enum
                col.length_range = length_range
    
    def print_columns_single_row(self):
        print("Name,Data Type,Is Not Null,Percent of Not Null Columns,Enum,Length Range")
        for column in self.get_columns():
            is_not_null = 'YES' if column.is_not_null else 'NO'
            percent_of_not_null_columns = column.percent_of_not_null_columns if column.percent_of_not_null_columns is not None else ''
            enum = column.enum if column.enum is not None else ''
            length_range = column.length_range if column.length_range is not None else ''
            
            print(f"{column.name},{column.data_type},{is_not_null},{percent_of_not_null_columns},{enum},{length_range}")

                
def parse_create_table_statement(create_statement):
    columns_obj = Columns()
    
    column_pattern = re.compile(r'(\w+)\s+([\w\(\)]+)\s*(NOT NULL)?', re.IGNORECASE)
    
    lines = create_statement.splitlines()
    for line in lines:
        match = column_pattern.search(line)
        if match:
            column_name = match.group(1)
            sql_data_type = match.group(2)
            is_not_null = bool(match.group(3))
            
            python_data_type = map_sql_to_python_type(sql_data_type)
            
            column = Column(name=column_name, data_type=python_data_type, is_not_null=is_not_null)
            columns_obj.add_column(column)
    
    ## columns_obj.print_columns_single_row()
    return columns_obj


def generate(use_gzip, columns_obj, file_name, file_start, file_records_in_file, config_filepath):
    read_config(config_filepath)
    
    if use_gzip:
        fh = gzip.open(file_name, mode='wt', newline='', encoding='utf-8')
    else:
        fh = open(file_name, mode='w', newline='')

    column_names = [column.name for column in columns_obj.get_columns()]

    with fh as file_handle:
        writer = csv.writer(file_handle)

        writer.writerow(column_names)

        datetime_generator = get_date_time_numeric(config_data['startdate'], config_data['enddate'], config_data['number_of_records'])
        adat = None

        rows = []
        uid = int(file_start)
        cid_count = {}
        for i in range(file_start, file_start+file_records_in_file):
            adat = next(datetime_generator)
            row = [] 
            for column in columns_obj.get_columns():
                if column.name.lower() == "uid":
                    if config_data['fixed_columns']['uid'][3] == "sequence":
                        row.append(uid)
                    else:
                        generatde_uid = get_random_int(column.enum)
                        row.append(generatde_uid)
                    uid+=1
                elif column.name.lower() == "cid":
                    cid = get_cid(column.enum)
                    cid = restrict_uids(uid, cid, column.enum, int(file_records_in_file), cid_count)
                    while cid is None:
                        cid = get_cid(column.enum)
                        cid = restrict_uids(uid, cid, column.enum, int(file_records_in_file), cid_count)
                    row.append(cid)
                elif column.name.lower() == "adat":
                    row.append(adat)
                elif column.name.lower() == "ad":
                    row.append(adat[:6])
                elif column.name.lower() == "ctime" or column.name.lower() == "c_time":
                    row.append(get_ctime(adat))
                elif column.name.lower() == "cdate" or column.name.lower() == "c_date":
                    row.append(get_ctime(adat)[:10])
                else:
                    if column.is_not_null == True:
                        if '-' in column.enum:
                            if column.data_type == "int":
                                row.append(get_random_int(column.enum))
                            elif column.data_type == "str":
                                row.append(get_random_string(column.length_range))
                        elif column.enum == "random":
                            if column.data_type == "int":
                                row.append(get_random_int(column.length_range))
                            elif column.data_type == "str":
                                row.append(get_random_string(column.length_range))
                        elif isinstance(column.enum, list):
                            range_str = "0-" + str(len(column.enum))
                            random_idx = get_random_int(range_str)
                            row.append(column.enum[random_idx])
                        else:
                            row.append(None)
                    else:
                        chance = random.randint(1, 100)
                        if chance <= column.percent_of_not_null_columns:
                            if '-' in column.enum:
                                if column.data_type == "int":
                                    row.append(get_random_int(column.enum))
                                elif column.data_type == "str":
                                    row.append(get_random_string(column.length_range))
                            if column.enum == "random":
                                if column.data_type == "int":
                                    row.append(get_random_int(column.length_range))
                                elif column.data_type == "str":
                                    row.append(get_random_string(column.length_range))
                                elif column.data_type == "datetime":
                                    row.append(get_random_datetime())
                                elif column.data_type == "float":
                                    row.append(get_random_float())
                            if isinstance(column.enum, list):
                                range_str = "0-" + str(len(column.enum))
                                random_idx = get_random_int(range_str)
                                row.append(column.enum[random_idx])
                        else:
                            row.append(None)
            # writer.writerow(row)
            rows.append(row)
            if len(rows) >= BATCH_SIZE:
                writer.writerows(rows)
                rows = []
        if len(rows) != 0:
            writer.writerows(rows)
            rows = []


def get_split_files(prefix, suffix):
    number_of_files = config_data['number_of_files']
    number_of_records = config_data['number_of_records']
    base_records_per_file = number_of_records // number_of_files
    remaining_records = number_of_records % number_of_files

    uid_start_val = config_data['uid_start_value']
    files = []

    for i in range(1, number_of_files + 1):
        if i == number_of_files:
            records_in_file = base_records_per_file + remaining_records
        else:
            records_in_file = base_records_per_file
        
        file_name = f'{prefix}_{uid_start_val}_{records_in_file}{suffix}'
        record = {
            "file_name": file_name,
            "start": uid_start_val,
            "records_in_file": records_in_file
        }
        files.append(record)
        
        uid_start_val += records_in_file
    
    return files

def read_export_object_and_parse(file_path, config_filepath):
    use_gzip = config_data['zipped_output']

    output_filename_prefix = config_data['output_file_path'] + f'_{int(time.time())}'
    output_filename_suffix = '.csv.gz' if use_gzip else '.csv'
    
    with open(file_path, 'r') as file:
        sql_content = file.read()
    
    columns_obj = parse_create_table_statement(sql_content)

    fixed_columns = config_data['fixed_columns']
    columns_obj.update_from_dict(fixed_columns)

    files = get_split_files(output_filename_prefix, output_filename_suffix)
    # for file in files:
    #     generate(use_gzip, columns_obj, file['file_name'], file['start'], file['records_in_file'], config_filepath)

    # client_specific_uids = {
    #     "-1": config_data['uid_start_value']
    # }
    # for client_id, _ in config_data['fixed_columns']['cid'][3].items():
    #     client_id = str(client_id)
    #     client_specific_uids[client_id] = config_data['uid_start_value']
    
    
    with concurrent.futures.ProcessPoolExecutor() as executor:
        futures = [executor.submit(generate, use_gzip, columns_obj, file['file_name'], file['start'], file['records_in_file'], config_filepath) for file in files]
        
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as e:
                print(f'Error during file generation: {e}')


def autogenerate():
    parser = argparse.ArgumentParser(description="Process the config file path.")
    parser.add_argument('--config', type=str, required=True, help="Path to the config file")
    args = parser.parse_args()
    config_filepath = args.config

    read_config(config_filepath)
    export_object_filepath = config_data['export_object_filepath']
    read_export_object_and_parse(export_object_filepath, config_filepath)


def test():
    '''
   
    read_export_object_and_parse(export_object_filepath)
    

    for i in range(100):
        inp = {
            72994: 50,
            12324: 20,
            56789: 10,
            -1: 20
        }
        val = get_cid(inp)
        print(val)
    
    get_date_time_numeric("230901000000", "", 10)

    
    for i in ["10-20", "30-40", "50-60", "60-80", "10-20", "30-40", "50-60", "60-80"]:
        print(get_random_string(i))
    
    gen = get_date_time_numeric("230901000000", "", 10)
    for i in gen:
        x = get_ctime(i)
        print(x, type(x))

    for i in range(100):
        print(get_cid({"72994": 50, "12345": 20, "67890": 10, "-1": 20}))
    '''

    # parser = argparse.ArgumentParser(description="Process the config file path.")
    # parser.add_argument('--config', type=str, required=True, help="Path to the config file")
    # args = parser.parse_args()
    # config_filepath = args.config
    # read_config(config_filepath)

    # files = get_split_files('../generated/generated_random_values', '.csv')
    # for i in files:
    #     print(i)

if __name__ == '__main__':
    start = time.time()
    autogenerate()
    print(time.time() - start)
    # test()
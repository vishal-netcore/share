import netgen as netgen

if __name__ == '__main__':
    netgen.autogenerate()
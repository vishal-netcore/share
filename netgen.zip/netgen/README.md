# Netgen Data Auto Generation Script
This Python script is designed to generate mock data based on a SQL CREATE TABLE statement and user-defined configurations provided in a JSON file. It supports generating various data types like integers, strings, floats, and datetimes. The generated data can be exported in either CSV or GZipped CSV formats.

### Running the script:
```
python3 autogenerate.py --config "<config_file_path>"
```

## Configuration
The script requires a configuration file in JSON format. The configuration file should contain the following keys:


```
{
    "zipped_output": true,
    "output_file_path": "/path/to/output/file",
    "export_object_filepath": "/path/to/export/object/file",
    "startdate": "230901000000",
    "enddate": "",
    "number_of_records": 1000,
    "fixed_columns": {
        "uid": ["int", true, 100, "random", "5-10"],
        "cid": ["int", true, 100, {"123": 50, "-1": 50}, ""],
        "adat": ["datetime", true, 100, "random", ""],
        "ad": ["str", true, 100, "random", "5-10"],
        "ctime": ["str", true, 100, "random", ""]
    },
    "default_random_string_length_range": "5-10",
    "default_random_int_range": "1-100",
    "default_percent_of_not_null_columns": 100,
    "default_enum": "random",
    "default_length_range": "5-10"
}
```

+ **zipped_output**: Set to true if you want the output in GZipped CSV format, otherwise false.
+ **output_file_path**: The file path where the generated CSV or GZipped CSV will be saved.
+ **export_object_filepath**: Path to the SQL CREATE TABLE statement file.
+ **startdate and enddate**: Datetime range for generating date-based values.
+ **number_of_records**: The number of mock records to generate.
+ **fixed_columns**: Define column names, data types, whether they are NOT NULL, and other properties like enum and length ranges for random generation.\
    The fixed_columns section defines specific settings for columns in the table schema:

    + *`column_name`*: The column's name.
    + *`data_type`*: Data type of the column (e.g., `"int"`, `"varchar"`, `"datetime"`).
    + *`is_not_null`*: Whether the column should be `NOT NULL` (`true` or `false`).
    + *`percent_of_not_null_columns`*: Percentage of non-null values if `is_not_null` is `false`.
    + *`enum`*: enum can be list of allowed values or `"random"` for random values or can be range for integer random values.
    + *`length_range`*: Length range for strings.

+ **default_random_string_length_range**: Default length range for random strings if not provided for a specific column.
+ **default_random_int_range**: Default integer range for random generation.
+ **default_percent_of_not_null_columns**: Default percentage of NOT NULL columns.
+ **default_enum**: Default enum value used for columns.
+ **default_length_range**: Default length range for strings.

## Features
+ **Dynamic SQL parsing**: The script parses SQL CREATE TABLE statements to infer columns and data types.
+ **Random data generation**: Generate mock data for various types including strings, integers, floats, and datetimes.
+ **Configurable output**: Supports both regular CSV and GZipped CSV formats.
+ **Custom randomization** logic: You can define custom ranges for strings, integers, and percentiles for NULL values.

### Command-line Arguments
| Argument	| Description                                   | 
|-----------|-----------------------------------------------|
| --config  | The path to the configuration file (required) |

## License
This software is confidential and proprietary to Netcore Cloud. Unauthorized copying, modification, or distribution is strictly prohibited.

## Author
Vishal Police Patil\
Netcore Cloud